/*
 * Copyright 2017 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "board.h"
#include "fsl_gpio.h"

#include "pin_mux.h"
#include "clock_config.h"
#include "fsl_debug_console.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define EXAMPLE_LED_GPIO BOARD_USER_LED_GPIO
#define EXAMPLE_LED_GPIO_PIN BOARD_USER_LED_GPIO_PIN


/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
volatile uint32_t g_systickCounter;
/* The PIN status */
volatile bool g_pinSet = false;

/*******************************************************************************
 * Code
 ******************************************************************************/
//#pragma location = "DATA_IN_DTCM"
uint8_t TestArray[1024*32];

//#pragma location = "CODE_IN_DTCM"
void delay_ms(uint16_t ms)
{
  volatile uint16_t iii,jjj;
  for(iii=0;iii<ms; iii++)
  {
    for ( jjj=0;jjj<20000; jjj++)
    {
      asm("nop");
    }
  }
}
//#pragma location = "CODE_IN_ITCM"
void delay_us(uint16_t us)
{
  volatile uint16_t iii,jjj;
  for(iii=0;iii<us; iii++)
  {
    for ( jjj=0;jjj<20; jjj++)
    {
      asm("nop");
    }
  }
}
//#pragma location = "CODE_IN_ITCM"
void SysTick_Handler(void)
{
    static uint32_t ii=0;
    if (g_systickCounter++>1000U)
    {
      g_systickCounter = 0;
      delay_ms(1);
      GPIO_PortToggle(GPIO1, 1<<5);
      
      PRINTF("\r\nToggle LED in SysTick_Handler =%d.\r\n", TestArray[ii]);
      ii++;
      if(ii==1024*32){
        ii=0;
      }
    }
}

void SysTick_DelayTicks(uint32_t n)
{
    g_systickCounter = n;
    while(g_systickCounter != 0U)
    {
    }
}

/*!
 * @brief Main function
 */
int mm;
int main(void)
{
    SCB->VTOR = 0x00001000;     //YNN
    /* Define the init structure for the output LED pin*/
    gpio_pin_config_t led_config = {kGPIO_DigitalOutput, 0, kGPIO_NoIntmode};
    
    /* Board pin init */
    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();

    PRINTF("YNN FlexRAM And Code Allocate Demonstrate Example.\r\n");
    for(mm=0;mm<1024*32;mm++)
    {
      TestArray[mm]=mm;
    }
    /* Init output LED GPIO. */
    GPIO_PinInit(EXAMPLE_LED_GPIO, EXAMPLE_LED_GPIO_PIN, &led_config);

    /* Set systick reload value to generate 1ms interrupt */
    if(SysTick_Config(SystemCoreClock / 1000U))
    {
        while(1)
        {
        }
    }
    while (1)
    { 
      delay_ms(2500);
      delay_us(10);
      PRINTF("\r\nYNN demo run in while(1)\r\n");
    }
//    while (1)
//    {
//        /* Delay 1000 ms */
//        SysTick_DelayTicks(1000U);
//        if (g_pinSet)
//        {
//            GPIO_PinWrite(EXAMPLE_LED_GPIO, EXAMPLE_LED_GPIO_PIN, 0U);
//            g_pinSet = false;
//        }
//        else
//        {
//            GPIO_PinWrite(EXAMPLE_LED_GPIO, EXAMPLE_LED_GPIO_PIN, 1U);
//            g_pinSet = true;
//        }
//    }
}
